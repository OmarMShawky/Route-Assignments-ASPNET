﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

namespace AssignmentSession4;

public class QuestionOne
{
    public static void QuestionOneMethod()
    {
        //A junior developer wrote this code to build a comma-separated list of 5,000 product IDs:
        //(a)Explain why this code is inefficient.Reference what happens in memory.
        //(b) Rewrite this code using StringBuilder to be more efficient.
        //(c) Add timing code(using Stopwatch) to both versions and report the time difference.

        //string productList = "";
        //for (int i = 1; i <= 5000; i++)
        //{
        //    productList += "PROD-" + i + ",";
        //}
        // strings are immutable (cannot change after creation)
        StringBuilder sb = new StringBuilder();

        for (int i = 1; i <= 5000; i++)
        {
            sb.Append("PROD-");
            sb.Append(i);
            sb.Append(",");
        }

        string productList = sb.ToString();
    }
}
