﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AssignmentSession4;
public class QuestionFive
{
    public static void QuestionFiveMethod()
    {
        int attempts = 0;
        bool isValid = false;

        do
        {
            Console.Write("Please Enter Your Password");
            string password = Console.ReadLine();

            bool hasUpper = false;
            bool hasLower = false;
            bool hasDigit = false;
            bool hasSpace = false;

            foreach (char c in password)
            {
                if (char.IsUpper(c)) hasUpper = true;
                if (char.IsUpper(c)) hasLower = true;
                if (char.IsDigit(c)) hasDigit = true;
                if (char.IsWhiteSpace(c)) hasSpace = true;
            }


            bool lengthValid = password.Length >= 8;

            if (!lengthValid)
                Console.WriteLine("Password must be at least 8 characters.");

            if (!hasUpper)
                Console.WriteLine("Password must contain at least one uppercase letter.");

            if (!hasLower)
                Console.WriteLine("Password must contain at least one lowercase letter.");

            if (!hasDigit)
                Console.WriteLine("Password must contain at least one digit.");

            if (hasSpace)
                Console.WriteLine("Password must not contain spaces.");

            // Final decision
            isValid = lengthValid && hasUpper && hasDigit && !hasSpace;

            if (isValid)
            {
                Console.WriteLine("Password is valid");
                break;
            }

            attempts++;

            if (attempts == 5)
            {
                Console.WriteLine("Account is locked.");
                break;
            }

        } while (!isValid);
    }
}
