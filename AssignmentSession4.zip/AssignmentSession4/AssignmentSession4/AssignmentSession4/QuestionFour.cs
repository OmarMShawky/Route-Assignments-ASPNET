﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AssignmentSession4;
public class QuestionFour
{
    public static void QuestionFourMethod()
    {
        int temperature = 35;

        string weatherAdvice = temperature < 0 ? "Freezing Stay Indoor" :
            temperature < 15 ? "Cold, Wear a jacekt" :
            temperature < 25 ? "Pleasant weather" :
            temperature < 35 ? "Warm stay hydrated" :
            "Hot, avoid the sun";

        // No it is not readable in case we have many conditions to check
        // it is prefered if we have one condition or 2 max
        // if condition is prefered in this example
    }
}
