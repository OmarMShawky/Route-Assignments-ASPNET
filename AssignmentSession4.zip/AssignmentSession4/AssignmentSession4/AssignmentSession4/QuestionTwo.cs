﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AssignmentSession4;

public class QuestionTwo
{
    public static void QuestionTwoMethod()
    {
        Console.WriteLine("Please Enter Your Age");
        int age = int.Parse(Console.ReadLine());
        decimal basePrice = 0;
        decimal WeekendSurcharge = 0;
        decimal priceAfterWeekendCheck = 0;
        decimal studentDiscount = 0;
        decimal finalPrice = 0;
        if (age < 5)
        {
            basePrice = 0;
            Console.WriteLine("Your Ticket is Free, Thank you");
            return;
        }

        else if (age <= 12)
            basePrice = 30;

        else if (age <= 59)
            basePrice = 50;

        else
            basePrice = 25;

        Console.WriteLine("Please Enter The Booking Day,\n" +
            "Sun = 1\n" +
            "Mon = 2\n" +
            "Tue = 3\n" +
            "Wed = 4\n" +
            "Thu = 5\n" +
            "Fri = 6\n" +
            "Sat = 7\n");

        int day = int.Parse(Console.ReadLine());

        if (day == 6 || day == 7)
            WeekendSurcharge = 10;

        priceAfterWeekendCheck = basePrice + WeekendSurcharge;

        Console.WriteLine("Do you have a valid student ID ?\nEnter true if YES , false if NO");
        bool isStudent = bool.Parse(Console.ReadLine());

        if (isStudent)
            studentDiscount = priceAfterWeekendCheck * 0.20m;
        

        finalPrice = priceAfterWeekendCheck - studentDiscount;

        Console.WriteLine("----- Receipt Details ------");
        Console.WriteLine($"Your Base Ticket Price = {basePrice}");
        Console.WriteLine($"Your Weekend Surcharge = {WeekendSurcharge}");
        Console.WriteLine($"Ticket Price after applying weekend Surcharge = {priceAfterWeekendCheck}");
        Console.WriteLine($"Your Student Discount = {studentDiscount}");
        Console.WriteLine($"Ticket Price after applying Student Discount = {finalPrice}");

    }
}

