﻿namespace AssignmentSession4;
internal class Program
{
    static void Main()
    {
        QuestionOne.QuestionOneMethod();
        //QuestionTwo.QuestionTwoMethod();
        //QuestionThree.QuestionThreeMethod();
        //QuestionFour.QuestionFourMethod();
        //QuestionFive.QuestionFiveMethod();
        //QuestionSix.QuestionSixMethod();
 
    }
}
