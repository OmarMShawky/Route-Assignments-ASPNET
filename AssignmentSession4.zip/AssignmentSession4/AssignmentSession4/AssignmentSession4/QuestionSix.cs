﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Net.NetworkInformation;
using System.Text;

namespace AssignmentSession4;

public class QuestionSix
{
    public static void QuestionSixMethod()
    {
        int[] scores = { 85, 42, 91, 67, 55, 78, 39, 88, 72, 95, 60, 48 };
        //Using loops(your choice of for, foreach, while), write code to:
        //(a)Find and display all failing scores(below 50)
        //(b) Find the first score above 90 and stop searching immediately
        //(c) Calculate the class average, excluding any scores below 40 (considered absent)


        for (int i = 0; i < scores.Length; i++)
        {
            if (scores[i] < 50)
                Console.WriteLine($"Failing Scores: {scores[i]}");
        }
        foreach (int s in scores)
        {
            if (s > 90)
            {
                Console.WriteLine($"First Score Above 90 = {s}");
                break;
            }
        }

        int totalScores = 0;
        int avgScores = 0;
        int count = 0;

        for (int i = 0; i < scores.Length; i++)
        {
            if (scores[i] >= 40)
            {
                totalScores += scores[i];
                count++;
            }
        }

        avgScores = totalScores / count;
        Console.WriteLine($"Average Class Scores = {avgScores}");

        //(d) Count how many students scored in each grade range:
        //○ A: 90-100
        //○ B: 80-89
        //○ C: 70-79
        //○ D: 60-69
        //○ F: Below 60

        int gradA = 0;
        int gradB = 0;
        int gradC = 0;
        int gradD = 0;
        int gradF = 0;
        foreach (int s in scores)
        {
            if (s >= 90) gradA++; else
            if (s >= 80) gradB++; else          
            if (s >= 70) gradC++; else           
            if (s >= 60) gradD++; else
            if (s < 60) gradF++;
        }

        Console.WriteLine($"{gradA} Students get Grad A");
        Console.WriteLine($"{gradB} Students get Grad B");
        Console.WriteLine($"{gradC} Students get Grad C");
        Console.WriteLine($"{gradD} Students get Grad D");
        Console.WriteLine($"{gradF} Students get Grad F");
    }
}
