﻿using System;
using System.Collections.Generic;
using System.Reflection.Metadata;
using System.Text;

namespace AssignmentSession4;

public class QuestionThree
{
    public static void QuestionThreeMethod()
    {
        string fileExtension = ".pdf";
        string fileType;

        // Switch Case
        switch (fileExtension)
        {
            case ".pdf":
                fileType = "PDF Document";
                break;

            case ".doc":
            case ".docx":
                fileType = "Word Document";
                break;

            case ".xlsx":
            case ".xls":
                fileType = "Excel Spreadsheet";
                break;

            case ".jpg":
            case ".png":
            case ".gif":
                fileType = "Image File";
                break;

            default:
                fileType = "Unknown File Type";
                break;
        }

        // switch expression
        string fileType2 = fileExtension switch
        {
            ".pdf" => "PDF Document",
            ".doc" or ".docx" => "Word Document",
            ".xls" or ".xlsx" => "Excel Spreadsheet",
            ".jpg" or ".png" or ".gif" => "Image File",
            _ => "Unknown File Type"
        };
    }
}