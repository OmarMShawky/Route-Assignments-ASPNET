﻿using System;
using System.Numerics;
using System.Xml.Linq;

namespace AssignmentSession3
{
    internal class Program
    {
        static void Main()
        {
            #region Q1

            //double d = 9.99;
            //int x = (int)d;
            //Console.WriteLine(x);
            /*
             * it will print 9 because 9.99 is converted to 9, explicit conversion from double to int
             */

            #endregion


            #region Q2
            //int n = 5;
            //double d2 = (double)n / 2; // (double) is added
            //Console.WriteLine(d2);


            #endregion


            #region Q3
            //Console.WriteLine("Please enter your age");
            //int age = Convert.ToInt32(Console.ReadLine());


            #endregion


            #region Q4
            //string s = "12a";
            //int x = int.Parse(s);
            //Console.WriteLine(x);
            /*
             * unhandled exception because "12a" can't be integer type
             * at run time, compiler throws unhandled exception
             */

            #endregion


            #region Q5
            //string s1 = "12a";
            //if (int.TryParse(s1, out int x1))
            //    Console.WriteLine(x1);
            //else
            //    Console.WriteLine("Invalid Conversion");


            #endregion


            #region Q6
            //object o = 10; // the integer 10 is boxed into an object.
            //int a = (int)o; // unboxing back to int.
            //Console.WriteLine(a + 1); // output = a + 1 = 10 + 1 = 11


            #endregion


            #region Q7
            //object o = 10; // 10 is boxed to int
            //long x = (long)o; // unboxing to long, but the object is integer
            //Console.WriteLine(x); // throw an exception.
            #endregion


            #region Q8
            //object o = 10;
            //long x = -1;   // default if conversion fails

            //if (o is long)
            //{
            //    x = (long)o;
            //}
            //else if (o is int)
            //{
            //    x = (int)o;   // implicit cast from int to long
            //}

            //Console.WriteLine(x);




            #endregion


            #region Q 9
            //string? name = null;
            //Console.WriteLine(name?.Length); // will print nothing because the name doesn't point to any object in the heap



            #endregion


            #region Q 10
            //string? name2 = null;
            //int length = name2?.Length ?? 0;
            //Console.WriteLine(length); // will print 0 because get the string is null, return 0 instead of crashing.

            #endregion


            #region Q 11
            //string? s = null;
            //int x = int.Parse(s ?? "0");
            //Console.WriteLine(x);
            // null-coalescing operator returns "0" instead of null.


            #endregion


            #region Q 12
            //string? s = null;
            //Console.WriteLine(s!.Length);
            // Unhandled exception. System.NullReferenceException: Object reference not set to an instance of an object.
            // to handle it
            //string? s2 = null;

            //if (s2 != null)
            //    Console.WriteLine(s2.Length);
            //else
            //    Console.WriteLine(0);

            #endregion


            #region Q 13

            //string? s = null; // s is null.
            //int x = Convert.ToInt32(s); // does NOT throw an exception.
            //Console.WriteLine(x); // It returns 0 by design.

            #endregion


            #region Q 14


            // string? s = null;
            // int a = int.Parse(s); // cannot accept null.
            // int b = Convert.ToInt32(s); // return 0 instead of throwing.
            // Console.WriteLine(b); // print 0

            #endregion


            #region Q 15
            //string user1 = "Omar";
            //string user2 = "";
            //string user3 = null;
            //Console.WriteLine(user1?.ToUpper() ?? "Guest"); // print OMAR in uppercase
            //Console.WriteLine(user2?.ToUpper() ?? "Guest"); // empthy space
            //Console.WriteLine(user3?.ToUpper() ?? "Guest"); // print Guest


            #endregion
        }
    }
}
